import sqlite3
from datetime import date, datetime, time, timedelta
from pathlib import Path
import streamlit as st

DB = Path(__file__).resolve().parent / "study_planner.db"

def db():
    con = sqlite3.connect(DB, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS sessions(
          id INTEGER PRIMARY KEY, subject TEXT NOT NULL, topic TEXT NOT NULL,
          study_date TEXT NOT NULL, start_time TEXT NOT NULL, minutes INTEGER NOT NULL,
          notes TEXT DEFAULT '', completed INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS assignments(
          id INTEGER PRIMARY KEY, title TEXT NOT NULL, subject TEXT NOT NULL,
          due_date TEXT NOT NULL, priority TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Not started',
          notes TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS exams(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, subject TEXT NOT NULL,
          exam_date TEXT NOT NULL, topics TEXT DEFAULT '');
        """)

def rows(sql, params=()):
    with db() as c:
        return c.execute(sql, params).fetchall()

def run(sql, params=()):
    with db() as c:
        c.execute(sql, params)

st.set_page_config(page_title="StudySpark", page_icon="📚", layout="wide")
st.markdown("""
<style>
.block-container{max-width:1200px;padding-top:1.5rem}
.hero{padding:1.25rem 1.5rem;border-radius:18px;background:linear-gradient(120deg,#eeeaff,#eaf7ff);margin-bottom:1rem}
.hero h1{margin:0;color:#252442}.hero p{margin:.3rem 0 0;color:#606780}
div[data-testid="stMetric"]{background:#fbfbfe;border:1px solid #e7e8f2;border-radius:14px;padding:12px}
</style>
""", unsafe_allow_html=True)
init_db()
today = date.today()
st.markdown('<div class="hero"><h1>📚 StudySpark</h1><p>Plan with purpose. Study consistently. Make progress visible.</p></div>', unsafe_allow_html=True)
with st.sidebar:
    st.title("StudySpark")
    page = st.radio("Navigate", ["Dashboard", "Timetable", "Assignments", "Exam countdown", "AI study assistant", "Study timer"])
    st.divider()
    st.caption("Your data is stored locally in SQLite.")

sessions = rows("SELECT * FROM sessions ORDER BY study_date,start_time")
assignments = rows("SELECT * FROM assignments ORDER BY due_date")
exams = rows("SELECT * FROM exams ORDER BY exam_date")

if page == "Dashboard":
    st.subheader("Progress dashboard")
    completed = [s for s in sessions if s["completed"]]
    week_start = today - timedelta(days=today.weekday())
    weekly = [s for s in completed if week_start.isoformat() <= s["study_date"] <= today.isoformat()]
    open_assign = [a for a in assignments if a["status"] != "Completed"]
    overdue = [a for a in open_assign if a["due_date"] < today.isoformat()]
    upcoming = [e for e in exams if e["exam_date"] >= today.isoformat()]
    m = st.columns(4)
    m[0].metric("Completed sessions", len(completed))
    m[1].metric("Study time this week", f"{sum(s['minutes'] for s in weekly)//60}h {sum(s['minutes'] for s in weekly)%60}m")
    m[2].metric("Open assignments", len(open_assign), delta=f"{len(overdue)} overdue" if overdue else None, delta_color="inverse")
    m[3].metric("Upcoming exams", len(upcoming))
    left, right = st.columns([1.2, 1])
    with left:
        st.markdown("### Weekly study time")
        chart = {}
        for i in range(7):
            d = week_start + timedelta(days=i)
            chart[d.strftime("%a %d")] = sum(s["minutes"] for s in completed if s["study_date"] == d.isoformat())
        st.bar_chart(chart)
    with right:
        st.markdown("### Today's timetable")
        today_sessions = [s for s in sessions if s["study_date"] == today.isoformat()]
        if not today_sessions:
            st.info("No sessions planned for today. Add one in Timetable.")
        for s in today_sessions:
            st.write(f"{'✅' if s['completed'] else '🕒'} **{s['start_time']} · {s['subject']}** — {s['topic']}")
        st.markdown("### Next deadlines")
        for a in open_assign[:5]:
            due = date.fromisoformat(a["due_date"])
            tag = "OVERDUE" if due < today else ("Due today" if due == today else f"Due {due:%d %b}")
            st.write(f"**{a['title']}** · {a['subject']} — {tag}")
    if not sessions and not assignments and not exams:
        st.info("Welcome! Use the navigation menu to add your first study session, assignment, or exam.")

elif page == "Timetable":
    st.subheader("Study timetable")
    with st.expander("＋ Plan a study session", expanded=not bool(sessions)):
        with st.form("session_form", clear_on_submit=True):
            a,b = st.columns(2)
            subject = a.text_input("Subject", placeholder="Biology")
            topic = b.text_input("Topic or task", placeholder="Cell structure")
            c,d,e = st.columns(3)
            sd = c.date_input("Study date", today)
            start = d.time_input("Start time", time(16,0))
            minutes = e.selectbox("Duration", [15,25,30,45,60,90,120,150,180], index=4, format_func=lambda x:f"{x} minutes")
            notes = st.text_area("Notes (optional)")
            submitted = st.form_submit_button("Add to timetable", type="primary", use_container_width=True)
            if submitted:
                if not subject.strip() or not topic.strip():
                    st.error("Enter both a subject and a topic.")
                else:
                    run("INSERT INTO sessions(subject,topic,study_date,start_time,minutes,notes) VALUES(?,?,?,?,?,?)",
                        (subject.strip(),topic.strip(),sd.isoformat(),start.strftime("%H:%M"),minutes,notes.strip()))
                    st.success("Session added.")
                    st.rerun()
    chosen = st.date_input("View timetable for", today, key="view_sessions")
    day_sessions = rows("SELECT * FROM sessions WHERE study_date=? ORDER BY start_time,id",(chosen.isoformat(),))
    st.markdown(f"### {chosen:%A, %d %B %Y}")
    if not day_sessions: st.info("No sessions planned for this date.")
    for s in day_sessions:
        with st.container(border=True):
            x,y,z = st.columns([.08,.72,.2], vertical_alignment="center")
            checked = x.checkbox("Done", bool(s["completed"]), key=f"done{s['id']}", label_visibility="collapsed")
            if checked != bool(s["completed"]):
                run("UPDATE sessions SET completed=? WHERE id=?",(int(checked),s["id"])); st.rerun()
            y.markdown(f"**{s['start_time']} · {s['subject']}** — {s['topic']}")
            y.caption(f"{s['minutes']} minutes · {'Completed' if s['completed'] else 'Planned'}" + (f" · {s['notes']}" if s["notes"] else ""))
            if z.button("Delete", key=f"ds{s['id']}"):
                run("DELETE FROM sessions WHERE id=?",(s["id"],)); st.rerun()

elif page == "Assignments":
    st.subheader("Assignment manager")
    with st.expander("＋ Add an assignment", expanded=not bool(assignments)):
        with st.form("assignment_form", clear_on_submit=True):
            title = st.text_input("Assignment title")
            subject = st.text_input("Subject", placeholder="Mathematics")
            a,b = st.columns(2)
            due = a.date_input("Due date", today + timedelta(days=7))
            priority = b.selectbox("Priority", ["Low","Medium","High"], index=1)
            notes = st.text_area("Notes (optional)")
            submit = st.form_submit_button("Save assignment", type="primary", use_container_width=True)
            if submit:
                if not title.strip() or not subject.strip(): st.error("Enter title and subject.")
                else:
                    run("INSERT INTO assignments(title,subject,due_date,priority,notes) VALUES(?,?,?,?,?)",
                        (title.strip(),subject.strip(),due.isoformat(),priority,notes.strip()))
                    st.success("Assignment saved."); st.rerun()
    filter_status = st.selectbox("Filter by status", ["All","Not started","In progress","Completed"])
    shown = [a for a in assignments if filter_status == "All" or a["status"] == filter_status]
    if not shown: st.info("No assignments match this filter.")
    for a in shown:
        due = date.fromisoformat(a["due_date"])
        due_label = "Completed" if a["status"] == "Completed" else ("OVERDUE" if due < today else ("DUE TODAY" if due == today else f"Due {due:%d %b %Y}"))
        with st.container(border=True):
            x,y,z = st.columns([.52,.30,.18], vertical_alignment="center")
            x.markdown(f"**{a['title']}**")
            x.caption(f"{a['subject']} · {due_label}" + (f" · {a['notes']}" if a["notes"] else ""))
            y.caption(f"Priority: **{a['priority']}**")
            status = y.selectbox("Status",["Not started","In progress","Completed"],index=["Not started","In progress","Completed"].index(a["status"]),key=f"ast{a['id']}",label_visibility="collapsed")
            if status != a["status"]:
                run("UPDATE assignments SET status=? WHERE id=?",(status,a["id"])); st.rerun()
            if z.button("Delete",key=f"da{a['id']}"):
                run("DELETE FROM assignments WHERE id=?",(a["id"],)); st.rerun()

elif page == "Exam countdown":
    st.subheader("Exam countdown")
    with st.expander("＋ Add an exam", expanded=not bool(exams)):
        with st.form("exam_form", clear_on_submit=True):
            a,b = st.columns(2)
            name = a.text_input("Exam name", placeholder="Final examination")
            subject = b.text_input("Subject", placeholder="Chemistry")
            exam_date = st.date_input("Exam date", today + timedelta(days=14))
            topics = st.text_area("Topics to revise (optional)")
            submit = st.form_submit_button("Add exam", type="primary", use_container_width=True)
            if submit:
                if not name.strip() or not subject.strip(): st.error("Enter exam name and subject.")
                elif exam_date < today: st.error("Choose today or a future date.")
                else:
                    run("INSERT INTO exams(name,subject,exam_date,topics) VALUES(?,?,?,?)",(name.strip(),subject.strip(),exam_date.isoformat(),topics.strip()))
                    st.success("Exam added."); st.rerun()
    upcoming = [e for e in exams if e["exam_date"] >= today.isoformat()]
    past = [e for e in exams if e["exam_date"] < today.isoformat()]
    if not upcoming: st.info("No upcoming exams recorded.")
    for i,e in enumerate(sorted(upcoming,key=lambda x:x["exam_date"])):
        day = date.fromisoformat(e["exam_date"]); left = (day-today).days
        with st.container(border=True):
            a,b = st.columns([.8,.2])
            a.markdown(f"### {left} day{'s' if left != 1 else ''} to go")
            a.markdown(f"**{e['name']}** · {e['subject']}")
            a.caption(f"{day:%A, %d %B %Y}")
            if e["topics"]: a.write(e["topics"])
            if left <= 3: a.warning("Prioritize key topics and practice questions; protect your sleep.")
            if b.button("Delete",key=f"de{e['id']}"): run("DELETE FROM exams WHERE id=?",(e["id"],)); st.rerun()
    if past:
        with st.expander("Past exams"):
            for e in past: st.write(f"{e['name']} · {e['subject']} · {e['exam_date']}")

elif page == "AI study assistant":
    st.subheader("AI study assistant")
    st.info("This starter includes a built-in study helper and does not require an API key. It generates structured plans and checklists, not live responses from an AI model.")
    kind = st.selectbox("What do you need help with?",["Create a study plan","Break down a topic","Prepare for an exam","Improve my study habits"])
    if kind == "Create a study plan":
        subjects = st.text_input("Subjects (separate with commas)",placeholder="Biology, Maths, English")
        hours = st.slider("Study time per day",1,10,3)
        days = st.slider("Plan length in days",1,14,7)
        weak = st.text_input("Subjects you find difficult (optional)")
        if st.button("Create my plan",type="primary"):
            items = [s.strip() for s in subjects.split(",") if s.strip()]
            if not items: st.error("Enter at least one subject.")
            else:
                st.markdown(f"### Your {days}-day plan")
                st.write(f"Daily target: **{hours} hours**. Use focused blocks with short breaks.")
                for i in range(days):
                    subj = items[i % len(items)]
                    other = items[(i+1) % len(items)]
                    with st.container(border=True):
                        st.markdown(f"**Day {i+1}**")
                        st.write(f"- {subj}: review notes and summarize key ideas.")
                        st.write(f"- {other}: practise questions and check your answers.")
                        st.write("- Finish with 10 minutes of active recall.")
                if weak: st.warning(f"Give extra practice to: {weak}.")
    elif kind == "Break down a topic":
        topic = st.text_input("Topic",placeholder="Photosynthesis")
        level = st.selectbox("Level",["Secondary school","College / university","Beginner","Advanced"])
        goal = st.text_area("What do you need to understand?")
        if st.button("Build a learning guide",type="primary"):
            if not topic.strip(): st.error("Enter a topic.")
            else:
                st.markdown(f"### Learning guide: {topic}")
                st.write(f"Level: {level}")
                st.write("1. Explain the topic in one sentence using your own words.")
                st.write("2. List key terms and define them.")
                st.write("3. Study one worked example, then try a similar example independently.")
                st.write("4. Close your notes and write everything you remember.")
                st.write("5. Explain the idea aloud as if teaching a classmate.")
                if goal: st.write(f"Your focus: {goal}")
                st.caption("This is a general framework. Add a language-model API for topic-specific generated explanations.")
    elif kind == "Prepare for an exam":
        subject = st.text_input("Exam subject",placeholder="Physics")
        exam_day = st.date_input("Exam date",today+timedelta(days=7),key="assist_exam")
        topics = st.text_area("Topics (one per line)")
        if st.button("Create revision checklist",type="primary"):
            if not subject.strip(): st.error("Enter the subject.")
            else:
                st.markdown(f"### Revision checklist — {subject}")
                st.write(f"Days remaining: **{max(0,(exam_day-today).days)}**")
                checklist = ["Gather syllabus, notes, and past questions","Identify topics needing the most practice"] + [f"Revise: {x.strip()}" for x in topics.splitlines() if x.strip()] + ["Complete a timed practice paper","Review mistakes and prepare exam materials"]
                for i,item in enumerate(checklist): st.checkbox(item,key=f"rev{i}")
    else:
        st.markdown("### A practical study routine")
        st.write("1. Set one specific goal before starting.")
        st.write("2. Focus for 25–50 minutes with notifications off.")
        st.write("3. Take a 5–10 minute break.")
        st.write("4. Use active recall and practice questions instead of only rereading.")
        st.write("5. Record what you learned and what to study next.")
        st.write("6. Keep daily goals realistic and protect your sleep.")

elif page == "Study timer":
    st.subheader("Study timer")
    st.write("Use focused work blocks and short breaks. This timer updates when you refresh it; it does not run background notifications.")
    if "timer_end" not in st.session_state: st.session_state.timer_end = None
    if "timer_label" not in st.session_state: st.session_state.timer_label = "Focused study"
    if "timer_minutes" not in st.session_state: st.session_state.timer_minutes = 25
    label = st.text_input("What are you working on?",st.session_state.timer_label)
    minutes = st.select_slider("Duration",options=[5,10,15,20,25,30,45,50,60,90],value=st.session_state.timer_minutes,format_func=lambda n:f"{n} minutes")
    st.session_state.timer_label, st.session_state.timer_minutes = label, minutes
    if st.session_state.timer_end is None:
        if st.button("▶ Start focus session",type="primary"):
            st.session_state.timer_end = (datetime.now()+timedelta(minutes=minutes)).timestamp(); st.rerun()
        if st.button("Start 5-minute break"):
            st.session_state.timer_label="Short break"; st.session_state.timer_minutes=5
            st.session_state.timer_end=(datetime.now()+timedelta(minutes=5)).timestamp(); st.rerun()
    else:
        remaining = max(0,int(st.session_state.timer_end-datetime.now().timestamp()))
        mm,ss = divmod(remaining,60)
        st.markdown(f"# {mm:02d}:{ss:02d}")
        st.progress(1-remaining/max(1,st.session_state.timer_minutes*60))
        if remaining == 0:
            st.success("Time is up! Take a break or begin another session.")
            st.session_state.timer_end=None
        else:
            st.caption(f"Current session: {st.session_state.timer_label}")
            a,b = st.columns(2)
            if a.button("↻ Refresh timer",type="primary"): st.rerun()
            if b.button("Stop timer"):
                st.session_state.timer_end=None; st.rerun()
            st.caption("Keep this tab open and refresh the display to update the countdown.")

st.divider()
st.caption("StudySpark · Streamlit + SQLite · Data is stored in study_planner.db beside app.py.")
